This directory contains the data for product vibrational level distributons in terms of DCS 
at theta = 30 (forward) and 150 degree (backward) for H2 (v=1-4, j=0) at Ecol = 0.25, 0.5, 
0.75 and 1.0 eV. The data correspond to Fig. S7 in the Electronic Supplementary Information. 

*** Important **
UC refers to uncoupled (single ground adiabatic state) and BD refers to coupled (BKMP2+DMBE)
state situations in the name of the files.
***************
